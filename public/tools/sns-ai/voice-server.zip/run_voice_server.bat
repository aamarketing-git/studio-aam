@echo off
chcp 65001 >nul
cd /d "%~dp0"
title SNS AI - My Voice Server (Qwen3-TTS)
rem Virtual env lives outside the site folder (OneDrive/Dropbox would otherwise sync several GB)
set "VENV=%LOCALAPPDATA%\snsai_voice\venv"
if exist "%VENV%\Scripts\python.exe" goto run
echo [1/2] Creating Python virtual environment in %VENV% ...
where uv >nul 2>nul && (uv venv "%VENV%" --python 3.12) || (py -3.12 -m venv "%VENV%" 2>nul || python -m venv "%VENV%")
if not exist "%VENV%\Scripts\python.exe" (
  echo Python 3.10+ is required. Install from https://www.python.org/downloads/
  pause
  exit /b 1
)
echo [2/2] Installing torch + qwen-tts - several GB, first time only...
where uv >nul 2>nul && (uv pip install --python "%VENV%\Scripts\python.exe" -r requirements.txt) || ("%VENV%\Scripts\python.exe" -m pip install --upgrade pip && "%VENV%\Scripts\python.exe" -m pip install -r requirements.txt)
:run
"%VENV%\Scripts\python.exe" qwen_voice_server.py %*
pause
