# -*- coding: utf-8 -*-
"""
SNS AI 마케팅 자동화 — 내 목소리(Qwen3-TTS 보이스 클로닝) 로컬 서버
==========================================================================
TubeInsight의 tts_engine.Qwen3VoiceCloner를 웹앱용으로 옮긴 독립 실행 서버입니다.
브라우저(웹앱)는 녹음한 참조 음성 + 참조 문장 + 읽을 대본을 보내고, 이 서버가 WAV를 돌려줍니다.
목소리 프로필은 브라우저에 저장되며, 서버는 상태를 저장하지 않습니다 (참조 음성 캐시만 임시 보관).

필요 패키지:  pip install torch qwen-tts soundfile numpy
실행:         python qwen_voice_server.py            (기본 http://127.0.0.1:8805)
옵션:         --port 8805  --host 127.0.0.1  --model Qwen/Qwen3-TTS-12Hz-0.6B-Base
              --allow-origin https://내사이트.com   (기본 * — 내 PC에서만 열리므로 보통 그대로 사용)
"""
import argparse
import base64
import hashlib
import io
import json
import os
import struct
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
import soundfile as sf

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

TARGET_SR = 24000
CACHE_DIR = os.path.join(tempfile.gettempdir(), "snsai_voice_refs")
os.makedirs(CACHE_DIR, exist_ok=True)
LANG = {"ko": "Korean", "en": "English", "ja": "Japanese", "zh": "Chinese"}


class Qwen3VoiceCloner:
    """
    Qwen3-TTS 제로샷 보이스 클로닝.
    모델 로드와 합성은 잠금으로 직렬화합니다 — 동시에 로드하면 'meta tensor' 오류로 전부 실패합니다.
    """
    model_id = "Qwen/Qwen3-TTS-12Hz-0.6B-Base"
    _model = None
    _device = None
    _lock = threading.RLock()

    @classmethod
    def get_model(cls):
        with cls._lock:
            if cls._model is None:
                import torch
                from qwen_tts import Qwen3TTSModel
                if torch.cuda.is_available():
                    cls._device, dtype = "cuda", torch.float16
                elif torch.backends.mps.is_available():
                    cls._device, dtype = "mps", torch.float32
                else:
                    cls._device, dtype = "cpu", torch.float32
                print(f"🔄 Qwen3-TTS 모델 로드 중 ({cls.model_id} · {cls._device}) — 처음에는 모델 다운로드로 몇 분 걸립니다...")
                try:
                    cls._model = Qwen3TTSModel.from_pretrained(cls.model_id, device_map=cls._device, dtype=dtype)
                except Exception as e:
                    print(f"  ⚠️ {cls._device} 로드 실패({e}) → CPU로 재시도")
                    cls._device = "cpu"
                    cls._model = Qwen3TTSModel.from_pretrained(cls.model_id, device_map="cpu", dtype=torch.float32)
                print("✅ Qwen3-TTS 모델 로드 완료")
            return cls._model

    @classmethod
    def clone(cls, text, ref_audio_path, ref_text, language="Korean"):
        with cls._lock:
            def run():
                model = cls.get_model()
                kw = dict(text=text, language=language, ref_audio=ref_audio_path)
                if ref_text:
                    kw["ref_text"] = ref_text
                else:
                    kw["x_vector_only_mode"] = True  # 참조 문장이 없으면 화자 임베딩만 사용
                return model.generate_voice_clone(**kw)
            try:
                wavs, sr = run()
            except Exception as e:
                if "meta tensor" in str(e):
                    cls._model = None  # 깨진 모델 버리고 한 번 더
                    wavs, sr = run()
                else:
                    raise
            return np.asarray(wavs[0], dtype=np.float32).reshape(-1), int(sr)


def deps_status():
    import importlib.util
    return {name: importlib.util.find_spec(mod) is not None for name, mod in (("torch", "torch"), ("qwen_tts", "qwen_tts"))}


def resample(x, sr, target=TARGET_SR):
    if sr == target or len(x) == 0:
        return x
    n = int(round(len(x) * target / sr))
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)


def to_wav_bytes(x, sr=TARGET_SR):
    """44바이트 헤더의 16bit PCM 모노 WAV (웹앱이 씬 음성을 이어 붙일 때 헤더 길이를 가정함)."""
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2").tobytes()
    header = b"RIFF" + struct.pack("<I", 36 + len(pcm)) + b"WAVEfmt " + struct.pack("<IHHIIHH", 16, 1, 1, sr, sr * 2, 2, 16) + b"data" + struct.pack("<I", len(pcm))
    return header + pcm


def save_ref_audio(data_url_or_b64):
    """참조 음성(base64)을 24kHz 모노 WAV로 캐시하고 경로를 반환 (같은 음성은 재사용)."""
    b64 = data_url_or_b64.split(",", 1)[1] if data_url_or_b64.startswith("data:") else data_url_or_b64
    raw = base64.b64decode(b64)
    key = hashlib.sha1(raw).hexdigest()[:20]
    path = os.path.join(CACHE_DIR, f"{key}.wav")
    if not os.path.exists(path):
        data, sr = sf.read(io.BytesIO(raw), dtype="float32", always_2d=True)
        mono = data[:, 0]
        mono = resample(mono, sr)[: TARGET_SR * 30]  # 30초까지만 사용
        if len(mono) < TARGET_SR * 2:
            raise ValueError("참조 음성이 너무 짧습니다. 5초 이상 녹음해주세요.")
        sf.write(path, mono, TARGET_SR, subtype="PCM_16")
    return path


class Handler(BaseHTTPRequestHandler):
    allow_origin = "*"
    server_version = "SNSAIVoice/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("  · %s\n" % (fmt % args))

    def cors(self):
        origin = self.headers.get("Origin") or "*"
        allowed = self.allow_origin == "*" or origin in [o.strip() for o in self.allow_origin.split(",")]
        self.send_header("Access-Control-Allow-Origin", origin if allowed else "null")
        self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Private-Network", "true")  # https 사이트 → 내 PC 접속 허용 (Chrome PNA)
        self.send_header("Access-Control-Expose-Headers", "X-Audio-Duration, X-Device")

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if self.path.split("?")[0] in ("/", "/health"):
            d = deps_status()
            return self.send_json({
                "ok": all(d.values()), "engine": "qwen3-tts", "model": Qwen3VoiceCloner.model_id,
                "loaded": Qwen3VoiceCloner._model is not None, "device": Qwen3VoiceCloner._device, "deps": d,
            })
        self.send_json({"error": "not found"}, 404)

    def do_POST(self):
        path = self.path.split("?")[0]
        try:
            length = int(self.headers.get("Content-Length") or 0)
            if length > 40 * 1024 * 1024:
                return self.send_json({"error": "요청이 너무 큽니다 (40MB 초과)."}, 413)
            data = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            return self.send_json({"error": "잘못된 요청 형식입니다."}, 400)

        if path == "/warmup":
            try:
                Qwen3VoiceCloner.get_model()
                return self.send_json({"ok": True, "device": Qwen3VoiceCloner._device})
            except Exception as e:
                return self.send_json({"error": f"모델 로드 실패: {e}"}, 500)

        if path != "/tts":
            return self.send_json({"error": "not found"}, 404)
        text = " ".join(str(data.get("text") or "").split())
        if len(text) < 2:
            return self.send_json({"error": "읽을 대본이 비어 있습니다."}, 400)
        if not data.get("ref_audio"):
            return self.send_json({"error": "참조 음성(ref_audio)이 없습니다."}, 400)
        if not all(deps_status().values()):
            return self.send_json({"error": "서버에 torch / qwen-tts가 설치되어 있지 않습니다. pip install torch qwen-tts"}, 500)
        try:
            ref_path = save_ref_audio(data["ref_audio"])
            lang = LANG.get(str(data.get("language") or "ko")[:2], data.get("language") or "Korean")
            t0 = time.time()
            wav, sr = Qwen3VoiceCloner.clone(text[:1000], ref_path, str(data.get("ref_text") or "").strip(), lang)
            wav = resample(wav, sr)
            body = to_wav_bytes(wav)
            dur = len(wav) / TARGET_SR
            print(f"  🎙️ {len(text)}자 → {dur:.1f}초 음성 ({time.time() - t0:.1f}초 소요, {Qwen3VoiceCloner._device})")
        except ValueError as e:
            return self.send_json({"error": str(e)}, 400)
        except Exception as e:
            print(f"  ⚠️ 합성 실패: {e}")
            return self.send_json({"error": f"보이스 클로닝 실패: {str(e)[:300]}"}, 500)
        self.send_response(200)
        self.cors()
        self.send_header("Content-Type", "audio/wav")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Audio-Duration", f"{dur:.3f}")
        self.send_header("X-Device", str(Qwen3VoiceCloner._device))
        self.end_headers()
        self.wfile.write(body)


def main():
    ap = argparse.ArgumentParser(description="Qwen3-TTS 보이스 클로닝 로컬 서버")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8805)
    ap.add_argument("--model", default=Qwen3VoiceCloner.model_id, help="예: Qwen/Qwen3-TTS-12Hz-1.7B-Base (GPU 권장)")
    ap.add_argument("--allow-origin", default="*", help="허용할 웹사이트 주소 (쉼표 구분, 기본 *)")
    ap.add_argument("--preload", action="store_true", help="시작할 때 모델을 미리 로드")
    a = ap.parse_args()
    Qwen3VoiceCloner.model_id = a.model
    Handler.allow_origin = a.allow_origin
    d = deps_status()
    print("=" * 60)
    print(" 🎙️  내 목소리 서버 (Qwen3-TTS 보이스 클로닝)")
    print(f"    주소   : http://{a.host}:{a.port}")
    print(f"    모델   : {a.model}")
    print(f"    패키지 : torch {'✅' if d['torch'] else '❌'} · qwen-tts {'✅' if d['qwen_tts'] else '❌'}")
    if not all(d.values()):
        print("    ⚠️  pip install torch qwen-tts soundfile numpy 로 설치해주세요.")
    print("    웹앱 → ② 기획 → '내 목소리 등록'에서 이 주소로 연결됩니다. 종료: Ctrl+C")
    print("=" * 60)
    if a.preload and all(d.values()):
        threading.Thread(target=Qwen3VoiceCloner.get_model, daemon=True).start()
    ThreadingHTTPServer((a.host, a.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
