#!/bin/bash
# macOS / Linux 실행 스크립트 — 처음 한 번 가상환경과 패키지(torch, qwen-tts)를 설치합니다.
# 가상환경은 사이트 폴더 밖에 만듭니다 (iCloud·Dropbox 등이 수 GB를 동기화하지 않도록).
cd "$(dirname "$0")"
VENV="${XDG_DATA_HOME:-$HOME/.local/share}/snsai_voice/venv"
if [ ! -x "$VENV/bin/python" ]; then
  echo "[1/2] 가상환경 만드는 중... ($VENV)"
  mkdir -p "$(dirname "$VENV")"
  python3 -m venv "$VENV" || { echo "Python 3.10 이상이 필요합니다."; exit 1; }
  echo "[2/2] torch + qwen-tts 설치 중 (수 GB · 처음 한 번만)..."
  "$VENV/bin/python" -m pip install --upgrade pip
  "$VENV/bin/python" -m pip install -r requirements.txt
fi
"$VENV/bin/python" qwen_voice_server.py "$@"
